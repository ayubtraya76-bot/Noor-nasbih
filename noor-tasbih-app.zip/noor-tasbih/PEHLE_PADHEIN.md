# Noor Tasbih: asli app banane ke tareeqe

Is folder mein teen cheezein hain:

- `web/` : poori app (offline chalti hai, phone par install hoti hai)
- `app/`, `build.gradle`, `settings.gradle`, `gradle.properties` : Android APK ka project
- `.github/workflows/build-apk.yml` : GitHub par APK apne aap banane ki file

---

## Tareeqa 1: Phone par seedha app (sabse aasan, free, 5 minute)

1. `web` folder ko kisi free hosting par daalein. Netlify Drop (netlify.com/drop) mein `web` folder drag-drop karein. Aapko ek `https://...` link milega.
2. Apne Android phone ke Chrome mein woh link kholein.
3. Chrome ka menu (teen dot) dabayein, phir **Install app** ya **Add to Home screen**.
4. Home screen par Noor Tasbih ka icon aa jayega. Yeh fullscreen khulta hai aur internet ke baghair bhi chalta hai.

Pehli baar internet par kholein, taaki Arabic ke khoobsurat fonts phone mein save ho jayein.

Dusron tak pahunchane ke liye wahi link bhej dein. Woh bhi isi tarah install kar lenge. iPhone par Safari mein Share dabayein, phir **Add to Home Screen**.

---

## Tareeqa 2: APK file (WhatsApp se bhejne ke liye)

1. github.com par free account banayein aur ek naya repository banayein (naam: noor-tasbih).
2. Is folder ki saari files repository mein upload karein. `.github` folder bhi upload hona chahiye (yeh kuch computers par chhupa hota hai).
3. Repository mein **Actions** tab kholein, **Build Noor Tasbih APK** chunein, phir **Run workflow** dabayein. 3 se 5 minute lagte hain.
4. Hara tick aane par us run ko kholein. Neeche **Artifacts** mein `noor-tasbih-apk` download karein. Zip ke andar `app-debug.apk` hai.
5. APK ko phone par bhejein aur kholein. Phone "unknown source" ki ijazat maangega, allow karein.

Zaroori: yeh Android project mujhse yahan build karke test nahi ho saka, kyunki is session mein Android ke download servers band the. Agar build fail ho to Actions mein error ka screenshot bhej dein, theek kar diya jayega.

Yeh debug APK hai, sirf seedhe share karne ke liye. Play Store ke liye Tareeqa 3 dekhein.

---

## Tareeqa 3: Google Play Store

1. Play Console developer account banayein (ek baar ki fees lagti hai, aur pehchaan verify hoti hai).
2. Tareeqa 1 wala `https://` link pwabuilder.com par daalein. Wahan se Android package (AAB) download karein.
3. Play Console mein naya app banayein, AAB upload karein, aur yeh bharein: privacy policy ka link, screenshots, app ki description, content rating.
4. Naye personal accounts par Google closed testing ki shart rakhta hai. Play Console mein current rule dekh lein.

iPhone ke App Store ke liye Mac aur Apple developer account chahiye. Uski jagah Tareeqa 1 (Safari se Add to Home Screen) kaafi hai.

---

## Dhyan dein

- Har phone ki ginti usi phone mein save hoti hai. Ek phone ki ginti doosre mein nahi dikhegi.
- Dusron tak bhejne se pehle Arabic text, matlab aur hawale kisi aalim se check karwa lein.
- App ka naam `Noor Tasbih` hai. Naam ya icon badalna ho to mujhe bata dein.
